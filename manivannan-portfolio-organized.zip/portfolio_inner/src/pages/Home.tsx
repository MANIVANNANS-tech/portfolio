import { useState } from "react";
import portrait from "../imports/image.png";
import { projects, skills } from "../data/portfolio";
import Spark from "../components/Spark";

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="poster-site">
      <header className="topbar">
        <a className="brand" href="#home">
          <strong>MS</strong>
          <span>Manivannan S.<br />AI Builder & Product Developer</span>
        </a>
        <nav className={menuOpen ? "open" : ""} aria-label="Main navigation">
          <a href="#about" onClick={() => setMenuOpen(false)}>About</a>
          <a href="#work" onClick={() => setMenuOpen(false)}>Work</a>
          <a href="#skills" onClick={() => setMenuOpen(false)}>Skills</a>
          <a href="#contact" onClick={() => setMenuOpen(false)}>Contact</a>
        </nav>
        <button
          className="menu"
          aria-label="Toggle navigation"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <span />
          <span />
        </button>
      </header>

      <main>
        <section className="intro" id="home">
          <div className="intro-copy">
            <p>FOUNDER · AI BUILDER · PRODUCT DEVELOPER</p>
            <h1>Building ideas<br />that <em>work.</em></h1>
          </div>
          <div className="intro-index">
            <span>PORTFOLIO</span>
            <strong>2026</strong>
          </div>
          <Spark className="intro-spark" />
          <span className="intro-ring" aria-hidden="true" />
        </section>

        <div className="card-stack">
          <section className="feature-card purple tilt-left" id="about">
            <div className="card-copy">
              <span className="card-kicker">01 / ABOUT ME</span>
              <h2>I build technology<br />with a purpose.</h2>
              <p>
                I turn real-world problems into practical AI products, intelligent
                automations and digital experiences that create meaningful impact.
              </p>
              <a href="#contact">Let&apos;s work together <b>↗</b></a>
            </div>
            <div className="portrait">
              <img src={portrait} alt="Manivannan with a laptop" />
            </div>
            <span className="yellow-ring" aria-hidden="true" />
          </section>

          <section className="feature-card pink tilt-right">
            <div className="big-number">02</div>
            <div className="card-copy wide">
              <span className="card-kicker">WHAT I DO</span>
              <h2>AI products, automation<br />and modern software.</h2>
              <p>
                From the first rough idea to a working product, I design and build
                systems that feel useful, simple and ready for the real world.
              </p>
            </div>
            <Spark className="pink-spark" />
          </section>

          <section className="feature-card yellow tilt-left" id="skills">
            <div className="card-copy full">
              <span className="card-kicker">03 / THE TOOLBOX</span>
              <h2>Tools I use to turn<br />ideas into products.</h2>
              <div className="skill-lines">
                {skills.map(([title, list]) => (
                  <div key={title}>
                    <strong>{title}</strong>
                    <span>{list}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="round-stamp">
              <span>BUILD • TEST • LEARN • SHIP •</span>
              <b>✦</b>
            </div>
          </section>

          <section className="feature-card ochre tilt-right">
            <div className="card-copy full venture-copy">
              <span className="card-kicker">04 / MY VENTURES</span>
              <div className="venture-line">
                <div>
                  <h2>Qbito Solutions</h2>
                  <p>AI automation, voice agents, websites and custom software.</p>
                </div>
                <b>↗</b>
              </div>
              <div className="venture-line">
                <div>
                  <h2>Ziko Innovation Hub</h2>
                  <p>Innovative AI products, MVPs and real-world technology.</p>
                </div>
                <b>↗</b>
              </div>
            </div>
          </section>
          <span className="stack-spark one" aria-hidden="true">✦</span>
          <span className="stack-spark two" aria-hidden="true">✦</span>
          <span className="stack-dot" aria-hidden="true" />
        </div>

        <section className="work" id="work">
          <div className="section-title">
            <div>
              <span>05 / SELECTED WORK</span>
              <h2>Things I&apos;ve built.</h2>
            </div>
            <p>Selected products, systems and experiments designed to solve actual problems.</p>
          </div>
          <div className="project-grid">
            {projects.map((project) => (
              <article className={`project-card ${project.color}`} key={project.title}>
                <div className="project-top">
                  <span>{project.number}</span>
                  <b>↗</b>
                </div>
                <div>
                  <small>{project.type}</small>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="experience">
          <div className="section-title">
            <div>
              <span>06 / EXPERIENCE</span>
              <h2>Building and shipping.</h2>
            </div>
          </div>
          <div className="experience-list">
            <article>
              <span>2024 — NOW</span>
              <div><h3>Founder</h3><p>Qbito Solutions</p></div>
              <b>AI automation, voice AI and custom digital solutions.</b>
            </article>
            <article>
              <span>2023 — NOW</span>
              <div><h3>Founder / Product Builder</h3><p>Ziko Innovation Hub</p></div>
              <b>AI products, innovative MVPs and technology prototypes.</b>
            </article>
          </div>
        </section>

        <section className="contact-card" id="contact">
          <span className="contact-kicker">HAVE AN IDEA?</span>
          <h2>Let&apos;s build something<br />meaningful.</h2>
          <p>Have a project, business problem or product idea?<br />Let&apos;s turn it into something real.</p>
          <a href="mailto:hello@manivannan.dev">GET IN TOUCH <b>↗</b></a>
          <Spark className="contact-spark" />
          <span className="contact-ring" aria-hidden="true" />
        </section>
      </main>

      <footer>
        <div><span>Created by</span><strong>Manivannan S.</strong></div>
        <div><span>Based in</span><strong>Tamil Nadu, India</strong></div>
        <div className="footer-links">
          <a href="https://github.com/MANIVANNANS-tech" target="_blank" rel="noreferrer">GitHub ↗</a>
          <a href="#contact">LinkedIn ↗</a>
        </div>
        <span className="bookmark" aria-hidden="true">♧</span>
      </footer>
    </div>
  );
}
