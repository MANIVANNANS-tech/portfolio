export const projects = [
  {
    number: "01",
    title: "AI Community",
    type: "AI / COMMUNITY",
    description: "A location-aware platform for discovering people, activities and communities.",
    color: "purple",
  },
  {
    number: "02",
    title: "Voice Agent",
    type: "VOICE AI / AUTOMATION",
    description: "An AI voice system for calls, lead capture and automated appointments.",
    color: "pink",
  },
  {
    number: "03",
    title: "Automation Systems",
    type: "AI / BUSINESS",
    description: "Intelligent workflows for onboarding, operations and repetitive business tasks.",
    color: "yellow",
  },
  {
    number: "04",
    title: "Digital Identity",
    type: "AI / FINTECH",
    description: "A secure digital identity concept for modern authentication experiences.",
    color: "ochre",
  },
  {
    number: "05",
    title: "Biometric Pay",
    type: "FINTECH / HARDWARE",
    description: "A cardless payment concept using palm recognition and biometrics.",
    color: "teal",
  },
  {
    number: "06",
    title: "Campus 8 Buddy",
    type: "AI / EDTECH",
    description: "An AI-powered college management and student collaboration platform.",
    color: "violet",
  },
];

export const skills = [
  ["AI & Automation", "AI Agents, OpenAI API, n8n, LangGraph, MCP, Voice AI"],
  ["Development", "React, JavaScript, Node.js, MERN, REST APIs, Supabase"],
  ["Product", "Product Ideation, MVP Development, Prototyping, Strategy"],
];

