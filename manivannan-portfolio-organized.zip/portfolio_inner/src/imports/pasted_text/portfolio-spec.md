{
  "project": {
    "name": "Manivannan S — Personal Portfolio",
    "type": "Personal Portfolio Website",
    "goal": "Create a premium, creative, modern personal portfolio for an AI-focused founder, AI builder, automation developer and product developer.",
    "reference_style": {
      "use_reference_images": true,
      "style_direction": [
        "Bold oversized typography",
        "Minimal editorial layout",
        "Creative portfolio aesthetic",
        "Strong visual hierarchy",
        "Large typography similar to the second reference image",
        "Playful geometric decorative elements similar to the first reference image",
        "Premium dark-mode interface",
        "Large whitespace",
        "Modern startup personality"
      ],
      "do_not_copy": [
        "Do not copy the exact layout",
        "Do not copy the exact text",
        "Do not copy another person's identity",
        "Do not reproduce the reference website pixel-for-pixel"
      ]
    }
  },

  "personal_information": {
    "name": "MANIVANNAN S",
    "short_name": "MANIVANNAN",
    "title": "Founder • AI Builder • Product Developer",
    "secondary_title": "AI Automation • Voice AI • Full-Stack Development",
    "location": "Tamil Nadu, India",
    "tagline": "Building AI-powered solutions for real-world problems.",
    "bio": "I build AI-powered products, intelligent automation systems and digital solutions that turn real-world problems into practical technology.",
    "github": "https://github.com/MANIVANNANS-tech",
    "linkedin": "[ADD_LINKEDIN_URL]",
    "email": "[ADD_EMAIL]",
    "phone": "[ADD_PHONE]"
  },

  "brand": {
    "personal_brand": "MANIVANNAN S",
    "ventures": [
      {
        "name": "Qbito Solutions",
        "role": "Founder",
        "description": "AI automation and software solutions agency."
      },
      {
        "name": "Ziko Innovation Hub",
        "role": "Founder / Product Builder",
        "description": "Innovation and AI product development venture focused on solving real-world problems."
      }
    ]
  },

  "design_system": {
    "mode": "dark",
    "visual_style": "Creative minimalism + modern technology + editorial portfolio",

    "colors": {
      "black": "#0A0A0A",
      "white": "#FFFFFF",
      "orange": "#FF9D2E",
      "dark_blue": "#102A43",
      "dark_green": "#123C32",
      "muted_white": "#D6D6D6",
      "gray": "#8A8A8A"
    },

    "color_usage": {
      "background": "black",
      "primary_text": "white",
      "headline": "white",
      "accent": "orange",
      "secondary_accent": "dark_blue",
      "tertiary_accent": "dark_green",
      "borders": "dark_blue",
      "hover_elements": "orange"
    },

    "typography": {
      "style": "Bold modern geometric sans-serif",
      "primary_font": "Use a font visually similar to the bold rounded typography in the second reference image",
      "recommended_fonts": [
        "Space Grotesk",
        "Sora",
        "Plus Jakarta Sans",
        "Inter"
      ],
      "headline_weight": "800",
      "subheadline_weight": "600",
      "body_weight": "400",
      "navigation_weight": "500",
      "headline_case": "Mixed case",
      "large_headlines": true,
      "letter_spacing": "tight"
    }
  },

  "layout": {
    "max_width": "1400px",
    "desktop_padding": "6vw",
    "tablet_padding": "5vw",
    "mobile_padding": "24px",
    "grid": "12-column responsive grid",
    "spacing": "Generous whitespace",
    "border_radius": "24px",
    "section_spacing": "large",
    "responsive": true
  },

  "navigation": {
    "position": "fixed top",
    "style": "minimal transparent navigation",
    "logo": "MS",
    "logo_style": "bold custom monogram",
    "links": [
      {
        "label": "Home",
        "target": "#home"
      },
      {
        "label": "About",
        "target": "#about"
      },
      {
        "label": "Work",
        "target": "#projects"
      },
      {
        "label": "Experience",
        "target": "#experience"
      },
      {
        "label": "Contact",
        "target": "#contact"
      }
    ],
    "mobile": {
      "type": "hamburger menu",
      "animation": "smooth slide-down"
    }
  },

  "hero_section": {
    "id": "home",
    "height": "100vh",
    "layout": "centered editorial composition",

    "eyebrow": "FOUNDER • AI BUILDER • PRODUCT DEVELOPER",

    "headline": [
      "Building",
      "AI-powered",
      "solutions",
      "for real-world",
      "problems."
    ],

    "headline_style": {
      "size": "clamp(4rem, 9vw, 9rem)",
      "weight": "800",
      "line_height": "0.92",
      "alignment": "left",
      "max_width": "1100px"
    },

    "highlight_words": [
      {
        "word": "AI-powered",
        "color": "orange"
      },
      {
        "word": "real-world",
        "color": "white"
      }
    ],

    "description": "I design, build and automate intelligent digital products using AI, automation and modern software technologies.",

    "cta": [
      {
        "label": "View My Work",
        "target": "#projects",
        "style": "orange filled button"
      },
      {
        "label": "Let's Connect",
        "target": "#contact",
        "style": "white outline button"
      }
    ],

    "visual_elements": [
      "floating orange circle",
      "dark blue geometric line",
      "dark green blob",
      "small plus symbols",
      "thin animated rings",
      "minimal floating dots"
    ]
  },

  "hero_animation": {
    "enabled": true,
    "type": "continuous looping animation",
    "animations": [
      {
        "element": "orange circle",
        "animation": "slow floating",
        "duration": "6s",
        "loop": "infinite",
        "easing": "ease-in-out"
      },
      {
        "element": "geometric rings",
        "animation": "slow rotation",
        "duration": "18s",
        "loop": "infinite"
      },
      {
        "element": "small decorative elements",
        "animation": "floating",
        "duration": "4s",
        "loop": "infinite"
      }
    ]
  },

  "about_section": {
    "id": "about",
    "layout": "two-column editorial",
    "left_column": {
      "label": "ABOUT ME",
      "headline": "I build technology with a purpose.",
      "description": "I am a technology entrepreneur and product builder focused on Artificial Intelligence, automation, software development and innovative product development. I enjoy transforming ideas and real-world problems into practical digital products."
    },

    "right_column": {
      "visual": "large personal portrait or professional profile image",
      "frame": {
        "style": "rounded asymmetric frame",
        "border": "thin orange and dark-blue animated border",
        "background": "dark_green"
      }
    },

    "decorations": [
      "animated plus symbol",
      "thin circular rings",
      "orange line",
      "dark blue geometric shape"
    ]
  },

  "about_animation": {
    "scroll_reveal": true,
    "image_animation": "slow scale + fade",
    "border_animation": "continuous subtle rotation",
    "text_animation": "slide-up"
  },

  "skills_section": {
    "id": "skills",
    "label": "WHAT I WORK WITH",
    "headline": "Tools I use to turn ideas into products.",

    "categories": [
      {
        "name": "AI & Automation",
        "skills": [
          "Artificial Intelligence",
          "AI Agents",
          "AI Automation",
          "OpenAI API",
          "n8n",
          "LangGraph",
          "MCP",
          "Voice AI"
        ]
      },
      {
        "name": "Development",
        "skills": [
          "React",
          "JavaScript",
          "Node.js",
          "MERN Stack",
          "REST APIs",
          "Supabase",
          "MongoDB"
        ]
      },
      {
        "name": "Tools",
        "skills": [
          "Git",
          "GitHub",
          "VS Code",
          "Vercel",
          "Ollama",
          "ElevenLabs"
        ]
      },
      {
        "name": "Product",
        "skills": [
          "Product Ideation",
          "MVP Development",
          "Prototype Development",
          "Problem Solving",
          "Product Strategy"
        ]
      }
    ],

    "style": "large interactive typography",
    "hover_effect": "skills slightly move upward and accent color changes to orange"
  },

  "projects_section": {
    "id": "projects",
    "label": "SELECTED WORK",
    "headline": "Things I've built.",

    "layout": "large editorial project cards",
    "grid": "alternating 2-column layout",

    "projects": [
      {
        "name": "AI-Powered Community Platform",
        "category": "AI / Community",
        "description": "A location-aware platform that helps people discover communities, activities and people based on their interests and location.",
        "technologies": [
          "AI",
          "Location Services",
          "Web Development"
        ],
        "featured": true
      },
      {
        "name": "AI Voice Agent",
        "category": "Voice AI / Automation",
        "description": "An AI-powered voice system designed to handle customer calls, answer questions, collect leads and automate appointment workflows.",
        "technologies": [
          "Voice AI",
          "ElevenLabs",
          "n8n",
          "AI APIs"
        ],
        "featured": true
      },
      {
        "name": "AI Automation Systems",
        "category": "AI Automation",
        "description": "Intelligent business workflows designed to automate repetitive tasks, customer onboarding and operational processes.",
        "technologies": [
          "n8n",
          "OpenAI",
          "APIs",
          "Webhooks"
        ]
      },
      {
        "name": "Digital Identity Platform",
        "category": "AI / FinTech",
        "description": "An AI-powered digital identity concept focused on modern authentication and secure digital experiences.",
        "technologies": [
          "AI",
          "Digital Identity",
          "Authentication"
        ]
      },
      {
        "name": "Biometric Payment Concept",
        "category": "FinTech / Hardware",
        "description": "An innovative cardless and cashless payment concept exploring biometric identification technology.",
        "technologies": [
          "Biometrics",
          "Palm Recognition",
          "FinTech",
          "Hardware"
        ]
      },
      {
        "name": "Campus 8 Buddy",
        "category": "EdTech",
        "description": "An AI-powered college management and student collaboration platform.",
        "technologies": [
          "AI",
          "EdTech",
          "Web Development"
        ]
      }
    ]
  },

  "project_card_animation": {
    "hover": {
      "scale": "1.02",
      "image_scale": "1.06",
      "duration": "0.5s",
      "overlay": "dark blue to transparent gradient",
      "title_color": "orange"
    },
    "scroll": {
      "reveal": "fade + translateY",
      "stagger": "0.12s"
    }
  },

  "experience_section": {
    "id": "experience",
    "label": "EXPERIENCE",
    "headline": "Building, experimenting and shipping.",

    "timeline": [
      {
        "role": "Founder",
        "company": "Qbito Solutions",
        "description": "Building AI automation, voice AI, websites, applications and custom digital solutions for businesses."
      },
      {
        "role": "Founder / Product Builder",
        "company": "Ziko Innovation Hub",
        "description": "Developing AI products, innovative software solutions, MVPs and hardware-software prototypes."
      }
    ],

    "timeline_style": {
      "line": "thin orange line",
      "nodes": "orange circles",
      "hover": "node expands with dark green glow"
    }
  },

  "ventures_section": {
    "label": "MY VENTURES",
    "layout": "two large editorial cards",

    "cards": [
      {
        "name": "Qbito Solutions",
        "role": "AI Automation Agency",
        "color": "dark_blue",
        "description": "AI automation, voice agents, websites, applications and custom digital solutions."
      },
      {
        "name": "Ziko Innovation Hub",
        "role": "AI Product & Innovation",
        "color": "dark_green",
        "description": "Building innovative AI products and real-world technology solutions."
      }
    ]
  },

  "contact_section": {
    "id": "contact",
    "layout": "large centered typography",
    "label": "HAVE AN IDEA?",
    "headline": "Let's build something meaningful.",
    "description": "Have a project, business problem or product idea? Let's turn it into something real.",

    "cta": {
      "label": "Get In Touch",
      "action": "mailto:[ADD_EMAIL]",
      "style": "large orange pill button"
    },

    "social_links": [
      "GitHub",
      "LinkedIn",
      "Instagram"
    ]
  },

  "footer": {
    "style": "minimal",
    "left": "MANIVANNAN S",
    "center": "Founder • AI Builder • Product Developer",
    "right": "© 2026",
    "background": "black"
  },

  "global_animation_system": {
    "enabled": true,
    "philosophy": "Everything should feel alive but never distracting.",

    "scroll": {
      "smooth_scrolling": true,
      "parallax": true,
      "section_reveal": true,
      "text_reveal": true,
      "image_reveal": true
    },

    "looping_animations": {
      "enabled": true,
      "infinite": true,

      "elements": [
        {
          "name": "floating_shapes",
          "movement": "slow vertical floating",
          "duration": "6s"
        },
        {
          "name": "rings",
          "movement": "continuous rotation",
          "duration": "20s"
        },
        {
          "name": "decorative_lines",
          "movement": "slow horizontal movement",
          "duration": "10s"
        },
        {
          "name": "plus_symbols",
          "movement": "small pulse and rotation",
          "duration": "5s"
        },
        {
          "name": "background_blobs",
          "movement": "slow morphing",
          "duration": "12s"
        }
      ]
    },

    "micro_interactions": {
      "buttons": "magnetic hover + subtle scale",
      "links": "underline animation",
      "cards": "lift + image zoom",
      "images": "subtle parallax",
      "cursor": "optional custom cursor with orange accent"
    },

    "performance": {
      "avoid_heavy_effects": true,
      "use_css_transforms": true,
      "use_requestAnimationFrame_when_needed": true,
      "respect_prefers_reduced_motion": true
    }
  },

  "visual_language": {
    "background": "predominantly black",
    "primary_text": "white",
    "accent": "orange",
    "secondary_visuals": [
      "dark blue",
      "dark green"
    ],
    "decorations": [
      "thin rings",
      "circles",
      "organic blobs",
      "plus symbols",
      "small dots",
      "curved lines",
      "rounded rectangular outlines"
    ],
    "composition": "Do not overcrowd the page. Use decorations strategically around large typography and images."
  },

  "responsive_design": {
    "desktop": {
      "layout": "full editorial experience",
      "headline": "very large",
      "animations": "full"
    },
    "tablet": {
      "layout": "simplified editorial grid",
      "headline": "large",
      "animations": "reduced"
    },
    "mobile": {
      "layout": "single column",
      "headline": "large but readable",
      "navigation": "hamburger",
      "animations": "lightweight",
      "decorations": "reduced but still visible"
    }
  },

  "technical_requirements": {
    "framework": "React",
    "styling": "Tailwind CSS",
    "animation": "Framer Motion",
    "icons": "Lucide React",
    "responsive": true,
    "seo": true,
    "accessibility": true,
    "fast_loading": true,
    "semantic_html": true
  },

  "important_design_instruction": {
    "instruction": "The portfolio should feel like a creative designer/developer portfolio rather than a traditional corporate website.",
    "priority": [
      "Typography first",
      "Strong whitespace",
      "Editorial composition",
      "Creative geometric elements",
      "Premium dark theme",
      "Smooth looping animations",
      "Excellent mobile experience"
    ],
    "avoid": [
      "Generic SaaS dashboard style",
      "Excessive glassmorphism",
      "Excessive gradients",
      "Too many cards",
      "Stock-looking UI",
      "Overloaded animations",
      "Random colors",
      "Tiny typography"
    ]
  }
}