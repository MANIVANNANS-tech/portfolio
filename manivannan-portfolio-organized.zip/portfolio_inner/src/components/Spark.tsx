type SparkProps = { className?: string };

export default function Spark({ className = "" }: SparkProps) {
  return (
    <span className={`spark ${className}`} aria-hidden="true">✦</span>
  );
}
